import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

// --- 1. SUPERCLASS ---
class Tentara {
    private String id;
    private String nama;
    private double hargaSewaPerHari;

    // Constructor
    public Tentara(String id, String nama, double hargaSewaPerHari) {
        this.id = id;
        this.nama = nama;
        this.hargaSewaPerHari = hargaSewaPerHari;
    }

    // Field status ketersediaan unit
    private LocalDate selesaiSewa = null; // null = tersedia

    // Getter
    public String getId() { return id; }
    public String getNama() { return nama; }
    public double getHargaSewaPerHari() { return hargaSewaPerHari; }
    public LocalDate getSelesaiSewa() { return selesaiSewa; }

    // Cek apakah unit tersedia (selesaiSewa null atau sudah lewat hari ini)
    public boolean isTersedia() {
        return selesaiSewa == null || !LocalDate.now().isBefore(selesaiSewa);
    }

    // Tandai unit sebagai disewa selama sekian hari mulai hari ini
    public void sewa(int hari) {
        this.selesaiSewa = LocalDate.now().plusDays(hari);
    }

    // Helper: format tanggal ke dd/MM/yyyy
    public String getStatusKetersediaan() {
        if (isTersedia()) {
            return "[TERSEDIA]";
        } else {
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            return "[DISEWA s/d " + selesaiSewa.format(fmt) + "]";
        }
    }

    // Method operasional - bisa di-override subclass
    public double hitungTotalSewa(int hari) {
        return hargaSewaPerHari * hari;
    }

    // Method untuk di-override
    public void tampilkanInfo() {
        System.out.printf("ID: %s | Nama: %s | Harga/hari: Rp%.0f | %s%n",
                id, nama, hargaSewaPerHari, getStatusKetersediaan());
    }
}

// --- 2. SUBCLASS 1: Sniper ---
// Sniper dikenakan biaya tambahan Rp500.000 per target yang dijanjikan
class Sniper extends Tentara {
    private int jumlahTarget; // Jumlah target yang bisa ditangani

    public Sniper(String id, String nama, double hargaSewaPerHari, int jumlahTarget) {
        super(id, nama, hargaSewaPerHari);
        this.jumlahTarget = jumlahTarget;
    }

    public int getJumlahTarget() { return jumlahTarget; }

    // Override: total sewa = (harga/hari * hari) + (Rp500.000 * jumlahTarget)
    @Override
    public double hitungTotalSewa(int hari) {
        double biayaTarget = jumlahTarget * 500_000.0;
        return (getHargaSewaPerHari() * hari) + biayaTarget;
    }

    @Override
    public void tampilkanInfo() {
        System.out.printf("ID: %s | Squad: %s (Penembak Jitu - %d target) | Harga/hari: Rp%.0f + Rp500.000/target | %s%n",
                getId(), getNama(), jumlahTarget, getHargaSewaPerHari(), getStatusKetersediaan());
    }
}

// --- 3. SUBCLASS 2: Assault ---
// Assault mendapat diskon 10% jika sewa lebih dari 7 hari
class Assault extends Tentara {
    private String senjataUtama;

    public Assault(String id, String nama, double hargaSewaPerHari, String senjataUtama) {
        super(id, nama, hargaSewaPerHari);
        this.senjataUtama = senjataUtama;
    }

    public String getSenjataUtama() { return senjataUtama; }

    // Override: diskon 10% jika sewa > 7 hari
    @Override
    public double hitungTotalSewa(int hari) {
        double total = getHargaSewaPerHari() * hari;
        if (hari > 7) {
            total = total * 0.9; // diskon 10%
        }
        return total;
    }

    @Override
    public void tampilkanInfo() {
        System.out.printf("ID: %s | Kompi: %s (Serbu - Senjata: %s) | Harga/hari: Rp%.0f (diskon 10%% jika >7 hari) | %s%n",
                getId(), getNama(), senjataUtama, getHargaSewaPerHari(), getStatusKetersediaan());
    }
}

// --- 4. MAIN CLASS ---
public class SistemSewaTentara {

    // Syarat: Menyimpan data menggunakan Array 2 Dimensi (Skor 25)
    // Format kolom: [Nama Penyewa, Nama Tentara, Lama Sewa (hari), Total Biaya]
    static String[][] riwayatTransaksi = new String[50][4];
    static int jumlahTransaksi = 0;

    public static void main(String[] args) {
        // Syarat: Data bisa diinput lewat keyboard (Skor 20)
        Scanner scanner = new Scanner(System.in);

        // Inisialisasi Objek (Polymorphism)
        Tentara[] daftarTentara = {
            new Sniper("S-01", "Squad Elang-1", 5_000_000, 3),
            new Sniper("S-02", "Squad Elang-2", 6_000_000, 5),
            new Assault("A-01", "Kompi Badai-1", 4_000_000, "M60 Machine Gun"),
            new Assault("A-02", "Kompi Badai-2", 4_500_000, "M4A1")
        };

        boolean berjalan = true;

        System.out.println("==========================================");
        System.out.println("  APLIKASI PENYEWAAN TENTARA BAYARAN C-4  ");
        System.out.println("==========================================");

        while (berjalan) {
            System.out.println("\nMenu Utama:");
            System.out.println("1. Tampilkan Daftar Tentara");
            System.out.println("2. Buat Transaksi Sewa");
            System.out.println("3. Lihat Riwayat Transaksi");
            System.out.println("4. Keluar");
            System.out.print("Pilih menu (1-4): ");

            int pilihan;
            try {
                pilihan = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Input tidak valid! Masukkan angka 1-4.");
                continue;
            }

            switch (pilihan) {
                case 1:
                    tampilkanTentara(daftarTentara);
                    break;
                case 2:
                    prosesTransaksi(scanner, daftarTentara);
                    break;
                case 3:
                    tampilkanRiwayat();
                    break;
                case 4:
                    berjalan = false;
                    System.out.println("Terima kasih telah menggunakan jasa kami!");
                    break;
                default:
                    System.out.println("Pilihan tidak valid! Masukkan angka 1-4.");
            }
        }
        scanner.close();
    }

    // Syarat: Memiliki minimal 2 method (Skor 20) -> Method 1
    public static void tampilkanTentara(Tentara[] daftar) {
        System.out.println("\n--- Daftar Tentara Bayaran Tersedia ---");
        System.out.println("-------------------------------------------------------");
        for (int i = 0; i < daftar.length; i++) {
            System.out.print((i + 1) + ". ");
            daftar[i].tampilkanInfo();
        }
        System.out.println("-------------------------------------------------------");
    }

    // Syarat: Memiliki minimal 1 transaksi (Skor 20) -> Method 2 (Transaksi)
    public static void prosesTransaksi(Scanner scanner, Tentara[] daftar) {
        System.out.print("\nMasukkan Nama Anda (Penyewa): ");
        String namaPenyewa = scanner.nextLine().trim();

        if (namaPenyewa.isEmpty()) {
            System.out.println("Gagal! Nama penyewa tidak boleh kosong.");
            return;
        }

        tampilkanTentara(daftar);
        System.out.print("Masukkan nomor urut (1-4) atau ID unit (contoh: S-01 / A-02): ");

        String inputPilihan = scanner.nextLine().trim();
        Tentara tentaraTerpilih = null;

        // Coba parse sebagai nomor urut
        try {
            int noUrut = Integer.parseInt(inputPilihan);
            if (noUrut >= 1 && noUrut <= daftar.length) {
                tentaraTerpilih = daftar[noUrut - 1];
            }
        } catch (NumberFormatException e) {
            // Bukan angka, cari berdasarkan ID (tidak case-sensitive)
            for (Tentara t : daftar) {
                if (t.getId().equalsIgnoreCase(inputPilihan)) {
                    tentaraTerpilih = t;
                    break;
                }
            }
        }

        if (tentaraTerpilih == null) {
            System.out.println("Gagal! Nomor urut atau ID unit tidak ditemukan.");
            return;
        }

        // Cek apakah unit sedang disewa
        if (!tentaraTerpilih.isTersedia()) {
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            System.out.println("Gagal! Unit " + tentaraTerpilih.getNama() +
                    " sedang disewa dan baru tersedia pada " +
                    tentaraTerpilih.getSelesaiSewa().format(fmt) + ".");
            return;
        }

        System.out.print("Berapa hari durasi sewa? ");
        int lamaSewa;
        try {
            lamaSewa = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Gagal! Input durasi sewa tidak valid.");
            return;
        }

        // Validasi: durasi sewa harus minimal 1 hari
        if (lamaSewa < 1) {
            System.out.println("Gagal! Durasi sewa minimal 1 hari.");
            return;
        }

        double totalBiaya = tentaraTerpilih.hitungTotalSewa(lamaSewa);

        System.out.println("\n========== STRUK TRANSAKSI ==========");
        System.out.println("Nama Penyewa  : " + namaPenyewa);
        System.out.println("Unit Disewa   : " + tentaraTerpilih.getNama());
        System.out.println("Durasi Sewa   : " + lamaSewa + " hari");

        // Tampilkan keterangan harga sesuai jenis unit
        if (tentaraTerpilih instanceof Sniper) {
            Sniper s = (Sniper) tentaraTerpilih;
            System.out.printf("Rincian       : (Rp%.0f x %d hari) + (Rp500.000 x %d target)%n",
                    s.getHargaSewaPerHari(), lamaSewa, s.getJumlahTarget());
        } else if (tentaraTerpilih instanceof Assault && lamaSewa > 7) {
            System.out.println("Keterangan    : Diskon 10% diterapkan (sewa > 7 hari)");
        }

        System.out.printf("Total Biaya   : Rp%.0f%n", totalBiaya);
        System.out.println("=====================================");

        // Simpan ke dalam array 2 dimensi
        if (jumlahTransaksi < riwayatTransaksi.length) {
            // Tandai unit sebagai disewa mulai hari ini
            tentaraTerpilih.sewa(lamaSewa);
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");

            riwayatTransaksi[jumlahTransaksi][0] = namaPenyewa;
            riwayatTransaksi[jumlahTransaksi][1] = tentaraTerpilih.getNama();
            riwayatTransaksi[jumlahTransaksi][2] = lamaSewa + " hari (s/d " + tentaraTerpilih.getSelesaiSewa().format(fmt) + ")";
            riwayatTransaksi[jumlahTransaksi][3] = String.format("%.0f", totalBiaya);
            jumlahTransaksi++;
            System.out.println("[Data Transaksi Berhasil Disimpan]");
            System.out.println("[Unit tersedia kembali pada: " + tentaraTerpilih.getSelesaiSewa().format(fmt) + "]");
        } else {
            System.out.println("[Error] Memori penyimpanan transaksi penuh!");
        }
    }

    // Method 3: Tampilkan riwayat dari array 2 dimensi
    public static void tampilkanRiwayat() {
        System.out.println("\n--- Riwayat Transaksi Sementara ---");
        if (jumlahTransaksi == 0) {
            System.out.println("Belum ada transaksi yang tercatat.");
        } else {
            System.out.println("-----------------------------------------------------------------");
            System.out.printf("%-5s | %-15s | %-20s | %-12s | %-15s%n",
                    "No", "Penyewa", "Unit", "Durasi", "Total Biaya");
            System.out.println("-----------------------------------------------------------------");
            for (int i = 0; i < jumlahTransaksi; i++) {
                System.out.printf("%-5d | %-15s | %-20s | %-12s | Rp%-15s%n",
                        (i + 1),
                        riwayatTransaksi[i][0],
                        riwayatTransaksi[i][1],
                        riwayatTransaksi[i][2],
                        riwayatTransaksi[i][3]);
            }
            System.out.println("-----------------------------------------------------------------");
            System.out.println("Total transaksi: " + jumlahTransaksi);
        }
    }
}